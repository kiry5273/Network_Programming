#!/bin/bash
g++ -o server server.cpp
mkdir ./build
mv server ./build/